/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Sora', 'system-ui', 'sans-serif'],
      },
      colors: {
        primary: {
          50: '#fdf9f0',
          100: '#f9f0dc',
          200: '#f0e0b8',
          300: '#e4ca8e',
          400: '#d4af63',
          500: '#c49a47',
          600: '#a87d35',
          700: '#855f2c',
          800: '#6b4d28',
          900: '#593f24',
          950: '#332415',
        },
        secondary: {
          50: '#fdf5f0',
          100: '#fae8df',
          200: '#f4d0c0',
          300: '#ecb094',
          400: '#e08a68',
          500: '#d06a45',
          600: '#b95330',
          700: '#973f25',
          800: '#7a3522',
          900: '#642d20',
          950: '#361710',
        },
        accent: {
          50: '#f6f7f9',
          100: '#eceef2',
          200: '#d5dae2',
          300: '#b0bac9',
          400: '#8595ab',
          500: '#657790',
          600: '#505f78',
          700: '#414e63',
          800: '#394353',
          900: '#343b48',
          950: '#22272f',
        },
      },
      animation: {
        'fade-in-up': 'fadeInUp 0.7s ease-out forwards',
        'blob': 'blob 8s infinite',
        'bounce-slow': 'bounce 2.5s infinite',
      },
      keyframes: {
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        blob: {
          '0%, 100%': { transform: 'translate(0px, 0px) scale(1)' },
          '33%': { transform: 'translate(20px, -30px) scale(1.05)' },
          '66%': { transform: 'translate(-15px, 15px) scale(0.97)' },
        },
      },
    },
  },
  plugins: [],
};
