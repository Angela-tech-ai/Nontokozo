import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Skills from '@/components/Skills';
import Education from '@/components/Education';
import Certifications from '@/components/Certifications';
import Projects from '@/components/Projects';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import { navLinks } from '@/data/portfolio';
import { useActiveSection } from '@/hooks/useActiveSection';

const sectionIds = ['home', ...navLinks.map((link) => link.href)];

function App() {
  const activeSection = useActiveSection(sectionIds);

  return (
    <div className="min-h-screen bg-white font-sans">
      <Navbar activeSection={activeSection} />
      <Hero />
      <About />
      <Skills />
      <Education />
      <Certifications />
      <Projects />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
