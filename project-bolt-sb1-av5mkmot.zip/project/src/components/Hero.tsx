import { useEffect, useState } from 'react';
import { ArrowDown, Github, Linkedin, Mail, Twitter } from 'lucide-react';
import { profile } from '@/data/portfolio';

export default function Hero() {
  const [roleIndex, setRoleIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setRoleIndex((i) => (i + 1) % profile.roles.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden bg-gradient-to-br from-primary-50 via-primary-100 to-white pt-28 pb-20"
    >
      <div className="pointer-events-none absolute -top-20 -left-20 h-96 w-96 rounded-full bg-primary-300/30 blur-3xl animate-blob" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-96 w-96 rounded-full bg-secondary-300/20 blur-3xl animate-blob [animation-delay:2s]" />

      <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-12 px-6 md:grid-cols-5">
        <div className="md:col-span-3 animate-fade-in-up">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/70 px-4 py-1.5 text-sm font-medium text-primary-700 ring-1 ring-inset ring-primary-200 backdrop-blur">
            <span className="h-2 w-2 rounded-full bg-secondary-500 animate-pulse" />
            Available for new opportunities
          </p>
          <h1 className="font-display text-4xl font-bold leading-tight text-primary-950 sm:text-5xl lg:text-6xl">
            Hi, I'm {profile.name.split(' ')[0]}.
            <br />
            <span className="text-secondary-600">I build products people love.</span>
          </h1>
          <div className="mt-5 h-8 text-lg font-medium text-primary-700 sm:text-xl">
            <span key={roleIndex} className="animate-fade-in-up inline-block">
              {profile.roles[roleIndex]}
            </span>
          </div>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-primary-700 sm:text-lg">
            {profile.tagline}
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <button
              onClick={() => scrollTo('projects')}
              className="rounded-full bg-secondary-600 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-secondary-900/20 transition-all hover:bg-secondary-500 hover:shadow-secondary-900/30"
            >
              View My Work
            </button>
            <button
              onClick={() => scrollTo('contact')}
              className="rounded-full border border-primary-300 bg-white/60 px-7 py-3.5 text-sm font-semibold text-primary-800 backdrop-blur transition-all hover:bg-white"
            >
              Get In Touch
            </button>
          </div>

          <div className="mt-10 flex items-center gap-4">
            <a
              href={profile.social.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-white/60 text-primary-700 ring-1 ring-inset ring-primary-200 transition-colors hover:bg-primary-600 hover:text-white"
            >
              <Github size={19} />
            </a>
            <a
              href={profile.social.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-white/60 text-primary-700 ring-1 ring-inset ring-primary-200 transition-colors hover:bg-primary-600 hover:text-white"
            >
              <Linkedin size={19} />
            </a>
            <a
              href={profile.social.twitter}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-white/60 text-primary-700 ring-1 ring-inset ring-primary-200 transition-colors hover:bg-primary-600 hover:text-white"
            >
              <Twitter size={19} />
            </a>
            <a
              href={`mailto:${profile.email}`}
              aria-label="Email"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-white/60 text-primary-700 ring-1 ring-inset ring-primary-200 transition-colors hover:bg-primary-600 hover:text-white"
            >
              <Mail size={19} />
            </a>
          </div>
        </div>

        <div className="md:col-span-2 flex justify-center animate-fade-in-up [animation-delay:150ms]">
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-br from-primary-300/40 to-secondary-300/30 blur-xl" />
            <div className="relative h-64 w-64 overflow-hidden rounded-[2rem] ring-4 ring-white/60 shadow-2xl sm:h-80 sm:w-80">
              <img
                src={profile.photo}
                alt={profile.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-5 -left-5 rounded-2xl bg-white px-5 py-3 shadow-xl ring-1 ring-primary-100">
              <p className="font-display text-2xl font-bold text-primary-800">3</p>
              <p className="text-xs font-medium text-primary-500">Years Study</p>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={() => scrollTo('about')}
        aria-label="Scroll to About section"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-primary-500 animate-bounce-slow"
      >
        <ArrowDown size={22} />
      </button>
    </section>
  );
}
