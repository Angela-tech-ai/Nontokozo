import { GraduationCap } from 'lucide-react';
import { education } from '@/data/portfolio';
import { useInView } from '@/hooks/useInView';

export default function Education() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="education" className="section-scroll-offset bg-white py-24">
      <div className="mx-auto max-w-4xl px-6">
        <div className="mb-14 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-secondary-600">
            Qualifications
          </span>
          <h2 className="mt-3 font-display text-3xl font-bold text-primary-900 sm:text-4xl">
            Education &amp; Training
          </h2>
        </div>

        <div ref={ref} className="relative">
          <div className="absolute left-6 top-2 bottom-2 w-px bg-primary-100 sm:left-1/2" />

          {education.map((item, index) => (
            <div
              key={item.degree}
              className={`relative mb-10 flex flex-col gap-4 sm:flex-row sm:items-start ${
                isInView ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="absolute left-6 top-1 flex h-9 w-9 -translate-x-1/2 items-center justify-center rounded-full bg-secondary-600 text-white ring-4 ring-white sm:left-1/2">
                <GraduationCap size={16} />
              </div>

              <div className="ml-16 rounded-2xl border border-primary-100 bg-primary-50/50 p-6 sm:ml-0 sm:w-1/2 sm:pr-10">
                <p className="mb-1 text-sm font-semibold text-secondary-600">{item.period}</p>
                <h3 className="font-display text-lg font-semibold text-primary-900">{item.degree}</h3>
                <p className="mb-2 text-sm font-medium text-primary-600">{item.institution}</p>
                <p className="text-sm leading-relaxed text-primary-600">{item.description}</p>
              </div>
              <div className="hidden sm:block sm:w-1/2" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
