import { Briefcase, Rocket, Smile, Trophy } from 'lucide-react';
import { profile } from '@/data/portfolio';
import { useInView } from '@/hooks/useInView';

const statIcons = [Briefcase, Rocket, Smile, Trophy];

export default function About() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="about" className="section-scroll-offset bg-white py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-14 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-secondary-600">
            About Me
          </span>
          <h2 className="mt-3 font-display text-3xl font-bold text-primary-900 sm:text-4xl">
            Turning ideas into reliable software
          </h2>
        </div>

        <div
          ref={ref}
          className={`grid grid-cols-1 gap-14 md:grid-cols-2 md:items-center ${
            isInView ? 'animate-fade-in-up' : 'opacity-0'
          }`}
        >
          <div className="relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-3 rounded-3xl bg-secondary-50" />
            <img
              src={profile.photo}
              alt={profile.name}
              className="relative w-full rounded-2xl object-cover shadow-xl"
            />
            <div className="absolute -bottom-6 -right-6 rounded-2xl bg-primary-900 px-5 py-4 text-white shadow-xl">
              <p className="text-xs font-medium text-primary-200">Based in</p>
              <p className="font-display font-semibold">{profile.location}</p>
            </div>
          </div>

          <div>
            {profile.bio.map((paragraph, index) => (
              <p key={index} className="mb-4 leading-relaxed text-primary-700">
                {paragraph}
              </p>
            ))}

            <div className="mt-8 grid grid-cols-2 gap-5">
              {profile.stats.map((stat, index) => {
                const Icon = statIcons[index % statIcons.length];
                return (
                  <div
                    key={stat.label}
                    className="rounded-xl border border-primary-100 bg-primary-50/50 p-4 transition-transform hover:-translate-y-1 hover:shadow-md"
                  >
                    <Icon className="mb-2 text-secondary-600" size={22} />
                    <p className="font-display text-2xl font-bold text-primary-900">{stat.value}</p>
                    <p className="text-sm text-primary-600">{stat.label}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
