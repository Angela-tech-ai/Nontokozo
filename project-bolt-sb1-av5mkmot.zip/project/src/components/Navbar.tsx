import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { navLinks, profile } from '@/data/portfolio';

type NavbarProps = {
  activeSection: string;
};

export default function Navbar({ activeSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setIsMenuOpen(false);
    document.getElementById(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'
      }`}
    >
      <nav className="max-w-6xl mx-auto px-6 flex items-center justify-between">
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-2 font-display font-bold text-lg"
        >
          <span
            className={`flex h-9 w-9 items-center justify-center rounded-lg bg-primary-600 text-white transition-colors ${
              isScrolled ? '' : 'ring-2 ring-primary-300'
            }`}
          >
            {profile.initials}
          </span>
          <span className={isScrolled ? 'text-primary-900' : 'text-primary-950'}>{profile.name}</span>
        </button>

        <ul className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <li key={link.href}>
              <button
                onClick={() => handleNavClick(link.href)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeSection === link.href
                    ? isScrolled
                      ? 'bg-primary-100 text-primary-800'
                      : 'bg-primary-200/70 text-primary-900'
                    : isScrolled
                    ? 'text-primary-700 hover:text-primary-900 hover:bg-primary-50'
                    : 'text-primary-700 hover:text-primary-900 hover:bg-primary-200/50'
                }`}
              >
                {link.label}
              </button>
            </li>
          ))}
        </ul>

        <button
          onClick={() => handleNavClick('contact')}
          className={`hidden md:inline-flex items-center rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${
            isScrolled
              ? 'bg-primary-600 text-white hover:bg-primary-700'
              : 'bg-primary-600 text-white hover:bg-primary-700'
          }`}
        >
          Let's Talk
        </button>

        <button
          className={`md:hidden p-2 rounded-lg ${isScrolled ? 'text-primary-900' : 'text-primary-950'}`}
          onClick={() => setIsMenuOpen((open) => !open)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {isMenuOpen && (
        <div className="md:hidden mt-3 mx-4 rounded-2xl bg-white shadow-lg border border-primary-100 overflow-hidden animate-fade-in-up">
          <ul className="flex flex-col divide-y divide-primary-50">
            {navLinks.map((link) => (
              <li key={link.href}>
                <button
                  onClick={() => handleNavClick(link.href)}
                  className={`w-full text-left px-5 py-3.5 text-sm font-medium ${
                    activeSection === link.href ? 'text-primary-800 bg-primary-50' : 'text-primary-800'
                  }`}
                >
                  {link.label}
                </button>
              </li>
            ))}
            <li>
              <button
                onClick={() => handleNavClick('contact')}
                className="w-full text-left px-5 py-3.5 text-sm font-semibold text-primary-700"
              >
                Let's Talk
              </button>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
