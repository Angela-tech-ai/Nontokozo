import { Award, ExternalLink } from 'lucide-react';
import { certifications } from '@/data/portfolio';
import { useInView } from '@/hooks/useInView';

export default function Certifications() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="certifications" className="section-scroll-offset bg-primary-50/60 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-14 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-secondary-600">
            Certifications
          </span>
          <h2 className="mt-3 font-display text-3xl font-bold text-primary-900 sm:text-4xl">
            Credentials &amp; Recognitions
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-600">
            Continuous learning that keeps my skills sharp and my work aligned with industry standards.
          </p>
        </div>

        <div ref={ref} className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {certifications.map((cert, index) => (
            <a
              key={cert.name}
              href={cert.credentialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className={`group flex flex-col rounded-2xl border border-primary-100 bg-white p-6 shadow-sm transition-all hover:-translate-y-1 hover:border-secondary-200 hover:shadow-lg ${
                isInView ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${index * 90}ms` }}
            >
              <div className="mb-4 flex items-start justify-between">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent-50 text-accent-600">
                  <Award size={22} />
                </span>
                <ExternalLink
                  size={16}
                  className="text-primary-300 transition-colors group-hover:text-secondary-600"
                />
              </div>
              <h3 className="mb-1 font-display text-base font-semibold leading-snug text-primary-900">
                {cert.name}
              </h3>
              <p className="text-sm font-medium text-primary-600">{cert.issuer}</p>
              <p className="mt-auto pt-4 text-xs text-primary-400">{cert.date}</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
