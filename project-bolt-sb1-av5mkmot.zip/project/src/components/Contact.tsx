import { ChangeEvent, FormEvent, useState } from 'react';
import { AlertCircle, CheckCircle2, Loader2, Mail, MapPin, Phone, Send } from 'lucide-react';
import { profile } from '@/data/portfolio';
import { supabase } from '@/lib/supabase';

type Status = 'idle' | 'submitting' | 'success' | 'error';

const initialForm = { name: '', email: '', subject: '', message: '' };

export default function Contact() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState<Status>('idle');

  const handleChange = (field: keyof typeof initialForm) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus('submitting');

    const { error } = await supabase.from('contact_messages').insert({
      name: form.name.trim(),
      email: form.email.trim(),
      subject: form.subject.trim(),
      message: form.message.trim(),
    });

    if (error) {
      setStatus('error');
      return;
    }

    setStatus('success');
    setForm(initialForm);
  };

  return (
    <section id="contact" className="section-scroll-offset bg-primary-950 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-14 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-secondary-400">
            Contact
          </span>
          <h2 className="mt-3 font-display text-3xl font-bold text-white sm:text-4xl">
            Let's build something great together
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-300">
            Have a project in mind or just want to say hello? My inbox is always open.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-10 md:grid-cols-5">
          <div className="md:col-span-2 space-y-5">
            <a
              href={`mailto:${profile.email}`}
              className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-5 transition-colors hover:bg-white/10"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-secondary-600/20 text-secondary-400">
                <Mail size={20} />
              </span>
              <div>
                <p className="text-xs text-primary-400">Email</p>
                <p className="font-medium text-white">{profile.email}</p>
              </div>
            </a>

            <a
              href={`tel:${profile.phone.replace(/[^+\d]/g, '')}`}
              className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-5 transition-colors hover:bg-white/10"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-secondary-600/20 text-secondary-400">
                <Phone size={20} />
              </span>
              <div>
                <p className="text-xs text-primary-400">Phone</p>
                <p className="font-medium text-white">{profile.phone}</p>
              </div>
            </a>

            <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-5">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-secondary-600/20 text-secondary-400">
                <MapPin size={20} />
              </span>
              <div>
                <p className="text-xs text-primary-400">Location</p>
                <p className="font-medium text-white">{profile.location}</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="md:col-span-3 rounded-2xl bg-white p-7 shadow-xl sm:p-8">
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-primary-800">Name</label>
                <input
                  required
                  type="text"
                  value={form.name}
                  onChange={handleChange('name')}
                  className="w-full rounded-lg border border-primary-200 px-4 py-2.5 text-sm text-primary-900 outline-none transition-colors focus:border-secondary-500 focus:ring-2 focus:ring-secondary-100"
                  placeholder="Jane Doe"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-primary-800">Email</label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={handleChange('email')}
                  className="w-full rounded-lg border border-primary-200 px-4 py-2.5 text-sm text-primary-900 outline-none transition-colors focus:border-secondary-500 focus:ring-2 focus:ring-secondary-100"
                  placeholder="jane@example.com"
                />
              </div>
            </div>

            <div className="mt-5">
              <label className="mb-1.5 block text-sm font-medium text-primary-800">Subject</label>
              <input
                required
                type="text"
                value={form.subject}
                onChange={handleChange('subject')}
                className="w-full rounded-lg border border-primary-200 px-4 py-2.5 text-sm text-primary-900 outline-none transition-colors focus:border-secondary-500 focus:ring-2 focus:ring-secondary-100"
                placeholder="Project inquiry"
              />
            </div>

            <div className="mt-5">
              <label className="mb-1.5 block text-sm font-medium text-primary-800">Message</label>
              <textarea
                required
                rows={4}
                value={form.message}
                onChange={handleChange('message')}
                className="w-full resize-none rounded-lg border border-primary-200 px-4 py-2.5 text-sm text-primary-900 outline-none transition-colors focus:border-secondary-500 focus:ring-2 focus:ring-secondary-100"
                placeholder="Tell me a bit about your project..."
              />
            </div>

            <button
              type="submit"
              disabled={status === 'submitting'}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-secondary-600 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-secondary-700 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {status === 'submitting' ? (
                <>
                  <Loader2 size={16} className="animate-spin" /> Sending...
                </>
              ) : (
                <>
                  <Send size={16} /> Send Message
                </>
              )}
            </button>

            {status === 'success' && (
              <p className="mt-4 flex items-center gap-2 text-sm font-medium text-secondary-700">
                <CheckCircle2 size={16} /> Thanks! Your message has been sent — I'll get back to you soon.
              </p>
            )}
            {status === 'error' && (
              <p className="mt-4 flex items-center gap-2 text-sm font-medium text-red-600">
                <AlertCircle size={16} /> Something went wrong sending your message. Please try again.
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
