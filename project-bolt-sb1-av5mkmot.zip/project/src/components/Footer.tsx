import { ArrowUp, Github, Linkedin, Mail, Twitter } from 'lucide-react';
import { navLinks, profile } from '@/data/portfolio';

export default function Footer() {
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  return (
    <footer className="bg-primary-950 border-t border-white/10 py-10">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-col items-center gap-6 sm:flex-row sm:justify-between">
          <div className="flex items-center gap-2 font-display font-bold text-white">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary-600 text-sm text-white">
              {profile.initials}
            </span>
            {profile.name}
          </div>

          <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-primary-300">
            {navLinks.map((link) => (
              <li key={link.href}>
                <button
                  onClick={() =>
                    document.getElementById(link.href)?.scrollIntoView({ behavior: 'smooth' })
                  }
                  className="transition-colors hover:text-white"
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <a
              href={profile.social.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-primary-300 transition-colors hover:bg-white/15 hover:text-white"
            >
              <Github size={16} />
            </a>
            <a
              href={profile.social.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-primary-300 transition-colors hover:bg-white/15 hover:text-white"
            >
              <Linkedin size={16} />
            </a>
            <a
              href={profile.social.twitter}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-primary-300 transition-colors hover:bg-white/15 hover:text-white"
            >
              <Twitter size={16} />
            </a>
            <a
              href={`mailto:${profile.email}`}
              aria-label="Email"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-primary-300 transition-colors hover:bg-white/15 hover:text-white"
            >
              <Mail size={16} />
            </a>
          </div>
        </div>

        <div className="mt-8 flex flex-col items-center gap-4 border-t border-white/10 pt-6 sm:flex-row sm:justify-between">
          <p className="text-xs text-primary-400">
            &copy; {new Date().getFullYear()} {profile.name}. All rights reserved.
          </p>
          <button
            onClick={scrollToTop}
            aria-label="Back to top"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-primary-300 transition-colors hover:bg-secondary-600 hover:text-white"
          >
            <ArrowUp size={16} />
          </button>
        </div>
      </div>
    </footer>
  );
}
