import { ExternalLink, Github } from 'lucide-react';
import { projects } from '@/data/portfolio';
import { useInView } from '@/hooks/useInView';

export default function Projects() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="projects" className="section-scroll-offset bg-white py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-14 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-secondary-600">
            Projects
          </span>
          <h2 className="mt-3 font-display text-3xl font-bold text-primary-900 sm:text-4xl">
            Selected Work
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-600">
            A few projects that reflect how I approach product, design, and engineering.
          </p>
        </div>

        <div ref={ref} className="grid grid-cols-1 gap-8 md:grid-cols-2">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className={`group overflow-hidden rounded-2xl border border-primary-100 bg-white shadow-sm transition-all hover:shadow-xl ${
                isInView ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${index * 120}ms` }}
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 flex items-end bg-gradient-to-t from-primary-950/70 via-transparent to-transparent p-5 opacity-0 transition-opacity group-hover:opacity-100">
                  <div className="flex gap-3">
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-semibold text-primary-900"
                    >
                      <ExternalLink size={14} /> Live Demo
                    </a>
                    <a
                      href={project.codeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-xs font-semibold text-white ring-1 ring-inset ring-white/30"
                    >
                      <Github size={14} /> Code
                    </a>
                  </div>
                </div>
                {project.featured && (
                  <span className="absolute right-4 top-4 rounded-full bg-secondary-600 px-3 py-1 text-xs font-semibold text-white shadow">
                    Featured
                  </span>
                )}
              </div>

              <div className="p-6">
                <h3 className="mb-2 font-display text-lg font-semibold text-primary-900">
                  {project.title}
                </h3>
                <p className="mb-4 text-sm leading-relaxed text-primary-600">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-secondary-50 px-3 py-1 text-xs font-medium text-secondary-700"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
