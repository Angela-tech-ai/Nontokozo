import { Code2, Server, Wrench } from 'lucide-react';
import { skillCategories } from '@/data/portfolio';
import { useInView } from '@/hooks/useInView';

const icons = { Code2, Server, Wrench };

function SkillBar({ name, level, isInView, delay }: { name: string; level: number; isInView: boolean; delay: number }) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <span className="font-medium text-primary-800">{name}</span>
        <span className="text-primary-500">{level}%</span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-primary-100">
        <div
          className="h-full rounded-full bg-gradient-to-r from-secondary-500 to-secondary-600 transition-all duration-1000 ease-out"
          style={{ width: isInView ? `${level}%` : '0%', transitionDelay: `${delay}ms` }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  const { ref, isInView } = useInView<HTMLDivElement>();

  return (
    <section id="skills" className="section-scroll-offset bg-primary-50/60 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-14 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-secondary-600">
            Skills
          </span>
          <h2 className="mt-3 font-display text-3xl font-bold text-primary-900 sm:text-4xl">
            Technologies I work with
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-600">
            A snapshot of the languages, frameworks, and tools I use to bring products to life.
          </p>
        </div>

        <div ref={ref} className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {skillCategories.map((category, catIndex) => {
            const Icon = icons[category.icon];
            return (
              <div
                key={category.title}
                className={`rounded-2xl border border-primary-100 bg-white p-7 shadow-sm transition-all hover:shadow-lg ${
                  isInView ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${catIndex * 120}ms` }}
              >
                <div className="mb-6 flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-secondary-50 text-secondary-600">
                    <Icon size={22} />
                  </span>
                  <h3 className="font-display text-lg font-semibold text-primary-900">
                    {category.title}
                  </h3>
                </div>
                <div className="space-y-5">
                  {category.skills.map((skill, index) => (
                    <SkillBar
                      key={skill.name}
                      name={skill.name}
                      level={skill.level}
                      isInView={isInView}
                      delay={index * 100}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
