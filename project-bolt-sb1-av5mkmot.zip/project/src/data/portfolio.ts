export const profile = {
  name: 'Nontokozo Angela Mnisi',
  initials: 'NM',
  roles: ['Software Developer', 'JavaScript & React Engineer', 'Python Developer'],
  tagline:
    'I build clean, user-focused applications that turn complex problems into simple, elegant digital solutions.',
  location: 'Johannesburg, South Africa',
  email: 'nontokozomnisi10@gmail.com',
  phone: '063 703 8823',
  resumeUrl: '#',
  photo: 'https://images.pexels.com/photos/12902899/pexels-photo-12902899.jpeg?auto=compress&cs=tinysrgb&h=900&w=900',
  social: {
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    twitter: 'https://twitter.com',
  },
  bio: [
    "I'm a software developer with a passion for building clean, user-focused applications. My core stack includes JavaScript, Python, and React, and I enjoy turning complex problems into simple, elegant digital solutions.",
    'When I am not writing code, I love learning new tools and exploring open-source projects. I believe great software comes from curiosity, collaboration, and a genuine care for the people who use what we build.',
  ],
  stats: [
    { label: 'Years of Study', value: '3' },
    { label: 'Core Technologies', value: '4+' },
    { label: 'Certifications', value: '3' },
    { label: 'Projects Built', value: '10+' },
  ],
};

export type SkillCategory = {
  title: string;
  icon: 'Code2' | 'Server' | 'Wrench';
  skills: { name: string; level: number }[];
};

export const skillCategories: SkillCategory[] = [
  {
    title: 'Programming Languages',
    icon: 'Code2',
    skills: [
      { name: 'JavaScript', level: 90 },
      { name: 'Python', level: 88 },
      { name: 'Java', level: 75 },
      { name: 'SQL', level: 82 },
    ],
  },
  {
    title: 'Frameworks & Tools',
    icon: 'Server',
    skills: [
      { name: 'React', level: 85 },
      { name: 'Node.js', level: 78 },
      { name: 'Git & Version Control', level: 85 },
      { name: 'Database Management (SQL)', level: 80 },
    ],
  },
  {
    title: 'Practices & Methods',
    icon: 'Wrench',
    skills: [
      { name: 'Structured Problem-Solving', level: 88 },
      { name: 'Agile & Collaboration', level: 85 },
      { name: 'Open-Source Exploration', level: 80 },
      { name: 'Continuous Learning', level: 92 },
    ],
  },
];

export type EducationItem = {
  degree: string;
  institution: string;
  period: string;
  description: string;
};

export const education: EducationItem[] = [
  {
    degree: 'Bachelor of Information Technology',
    institution: 'University of Johannesburg',
    period: '2021 - 2023',
    description:
      'Completed a Bachelor in Information Technology with two core joint majors: Computer Science and Informatics. Built a strong foundation in software development, databases, and systems thinking.',
  },
  {
    degree: 'National Senior Certificate',
    institution: 'High School, South Africa',
    period: '2020',
    description:
      'Achieved high marks in Mathematics and English with an overall average of 77%, laying the groundwork for a career in technology and problem-solving.',
  },
];

export type Certification = {
  name: string;
  issuer: string;
  date: string;
  credentialUrl: string;
};

export const certifications: Certification[] = [
  {
    name: 'Google AI Essentials Certificate',
    issuer: 'Google',
    date: 'Issued 2024',
    credentialUrl: '#',
  },
  {
    name: 'Google Professional Cloud Developer',
    issuer: 'Google Cloud',
    date: 'Issued 2024',
    credentialUrl: '#',
  },
  {
    name: 'AWS Certified Developer',
    issuer: 'Amazon Web Services',
    date: 'Issued 2023',
    credentialUrl: '#',
  },
];

export type Project = {
  title: string;
  description: string;
  image: string;
  tags: string[];
  liveUrl: string;
  codeUrl: string;
  featured: boolean;
};

export const projects: Project[] = [
  {
    title: 'Data Insights Dashboard',
    description:
      'A responsive analytics dashboard built with React that visualizes datasets with interactive charts, filters, and exportable reports for quick decision-making.',
    image: 'https://images.pexels.com/photos/577210/pexels-photo-577210.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200',
    tags: ['React', 'JavaScript', 'Data Visualization'],
    liveUrl: '#',
    codeUrl: '#',
    featured: true,
  },
  {
    title: 'Python Automation Toolkit',
    description:
      'A collection of Python scripts that automate repetitive file and data tasks, saving hours of manual work through clean, reusable command-line tools.',
    image: 'https://images.pexels.com/photos/5242012/pexels-photo-5242012.png?auto=compress&cs=tinysrgb&h=800&w=1200',
    tags: ['Python', 'Automation', 'CLI'],
    liveUrl: '#',
    codeUrl: '#',
    featured: true,
  },
  {
    title: 'TaskFlow Web App',
    description:
      'A minimal task management application with drag-and-drop boards, due-date reminders, and a clean interface designed for focus and productivity.',
    image: 'https://images.pexels.com/photos/1181279/pexels-photo-1181279.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200',
    tags: ['React', 'JavaScript', 'UI/UX'],
    liveUrl: '#',
    codeUrl: '#',
    featured: false,
  },
  {
    title: 'Mobile Companion Concept',
    description:
      'A concept mobile interface exploring onboarding flows and accessibility-first design, prototyped to demonstrate clean navigation and warm visual feedback.',
    image: 'https://images.pexels.com/photos/248528/pexels-photo-248528.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200',
    tags: ['UI/UX', 'React', 'Accessibility'],
    liveUrl: '#',
    codeUrl: '#',
    featured: false,
  },
];

export const navLinks = [
  { label: 'About', href: 'about' },
  { label: 'Skills', href: 'skills' },
  { label: 'Education', href: 'education' },
  { label: 'Certifications', href: 'certifications' },
  { label: 'Projects', href: 'projects' },
  { label: 'Contact', href: 'contact' },
];
