/*
# Create contact messages table

1. Plain-English summary
   Visitors to the portfolio site can send a message through the Contact
   form. This migration creates a place to store those messages so the
   site owner never loses an inquiry, even after the visitor closes their
   browser.

2. New Tables
   - `contact_messages`
     - `id` (uuid, primary key) - unique identifier for the message
     - `name` (text, not null) - sender's name
     - `email` (text, not null) - sender's email address, for replying
     - `subject` (text, not null) - short subject line
     - `message` (text, not null) - the message body
     - `created_at` (timestamptz, default now()) - when it was sent

3. Security
   - Row Level Security is enabled on `contact_messages`.
   - A single INSERT policy allows anyone (anon + authenticated) to submit
     a message, since this is a public contact form with no login.
   - No SELECT, UPDATE, or DELETE policy is created for anon/authenticated,
     so submitted messages cannot be read, changed, or removed from the
     browser by anyone, including the sender. The site owner reviews
     messages directly in the Supabase dashboard.
*/

CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_contact_messages" ON contact_messages;
CREATE POLICY "anon_insert_contact_messages" ON contact_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);
